import static org.junit.jupiter.api.Assertions.assertTrue;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class EditExistingContact {
	
public static void main(String[] args) {
	
		// 1.) set the property for webdriver.chrome.driver to be the location of  your
				//local computer
				System.setProperty("webdriver.chrome.driver", "C:\\$INFO_6067\\Selenium_TFT\\chromedriver_win32_2.4\\chromedriver.exe");
				
				
				// 2.)Create new instance of chrome driver
				WebDriver driver =new ChromeDriver();
				
				// 3.) Use instance of chrome driver to visit google
				driver.get("http://localhost/index.php");
				
				driver.findElement(By.linkText("List All Entries")).click();
				
				driver.findElement(By.xpath("/html/body/table/tbody/tr[4]/td[4]/form[2]/input[3]")).click();
				
				// Editing of Existing form 
				WebElement addr_type = driver.findElement(By.id("addr_type"));
				addr_type.sendKeys("Friend");
				
				WebElement addr_first_name = driver.findElement(By.id("addr_first_name"));
				// clear the value in field to enter new value
				addr_first_name.clear();
				addr_first_name.sendKeys("Amanjot");
				
				WebElement addr_last_name = driver.findElement(By.id("addr_last_name"));
				addr_last_name.clear();
				addr_last_name.sendKeys("kaur");
				
				WebElement addr_business = driver.findElement(By.id("addr_business"));
				addr_business.clear();
				addr_business.sendKeys("AMY");
				
				WebElement addr_addr_line_1 = driver.findElement(By.id("addr_addr_line_1"));
				addr_addr_line_1.clear();
				addr_addr_line_1.sendKeys("678  st.");
				
				WebElement addr_addr_line_2 = driver.findElement(By.id("addr_addr_line_2"));
				addr_addr_line_2.clear();
				addr_addr_line_2.sendKeys(" adelaide ");
				
				WebElement addr_addr_line_3 = driver.findElement(By.id("addr_addr_line_3"));
				addr_addr_line_3.clear();
				addr_addr_line_3.sendKeys("ontario");
				
				WebElement addr_city = driver.findElement(By.id("addr_city"));
				addr_city.clear();
				addr_city.sendKeys("London");
				
				WebElement addr_region = driver.findElement(By.id("addr_region"));
				addr_region.clear();
				addr_region.sendKeys("North");
				
				WebElement addr_country = driver.findElement(By.id("addr_country"));
				addr_country.clear();
				addr_country.sendKeys("America");
				
				WebElement addr_post_code = driver.findElement(By.id("addr_post_code"));
				addr_post_code.clear();
				addr_post_code.sendKeys("N5E4O9");
				
				WebElement addr_email_1 = driver.findElement(By.id("addr_email_1"));
				addr_email_1.clear();
				addr_email_1.sendKeys("amanjot70@gmail.com");
				
				WebElement addr_email_2 = driver.findElement(By.id("addr_email_2"));
				addr_email_2.clear();
				addr_email_2.sendKeys("amanjot80@gmail.com");
				
				WebElement addr_email_3 = driver.findElement(By.id("addr_email_3"));
				addr_email_3.clear();
				addr_email_3.sendKeys("90amanjot90@gmail.com");
				
				WebElement addr_phone_1_type = driver.findElement(By.id("addr_phone_1_type"));
				
				addr_phone_1_type.sendKeys("Home");
				
				WebElement addr_phone_1 = driver.findElement(By.id("addr_phone_1"));
				addr_phone_1.clear();
				addr_phone_1.sendKeys("5196707531");
				
				WebElement addr_phone_2_type = driver.findElement(By.id("addr_phone_2_type"));
				
				addr_phone_2_type.sendKeys("Mobile");
				
				WebElement addr_phone_2 = driver.findElement(By.id("addr_phone_2"));
				addr_phone_2.clear();
				addr_phone_2.sendKeys("5987897653");
				
				WebElement addr_phone_3_type = driver.findElement(By.id("addr_phone_3_type"));
			addr_phone_3_type.sendKeys("Work");
			
				WebElement addr_phone_3 = driver.findElement(By.id("addr_phone_3"));
				addr_phone_3.clear();
				addr_phone_3.sendKeys("60075319874");
				
				
				
				WebElement addr_web_url_1 = driver.findElement(By.id("addr_web_url_1"));
				addr_web_url_1.clear();
				addr_web_url_1.sendKeys("www.amazon.com");
				
				WebElement addr_web_url_2 = driver.findElement(By.id("addr_web_url_2"));
				addr_web_url_2.clear();
				addr_web_url_2.sendKeys("www.walmart.com");
				
				WebElement addr_web_url_3 = driver.findElement(By.id("addr_web_url_3"));
				addr_web_url_3.clear();
				addr_web_url_3.sendKeys("www.gmail.com");
				
				//Click on save address button
				driver.findElement(By.name("submit_button")).submit();
				
				// Assertion Part 
				 String actualResult = driver.findElement(By.xpath("/html/body/form/div/h2")).getText();
				 String expectedResult = "The address book entry was updated successfully";
				 boolean result = actualResult.equals(expectedResult);
			     assertTrue( result);
			     System.out.println("It successfully edit the contact");
}
}
