import static org.junit.jupiter.api.Assertions.assertTrue;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class TestAddNewContact {
	public static void main(String[] args) {

	
	// 1.) set the property for webdriver.chrome.driver to be the location of  your
			//local computer
			System.setProperty("webdriver.chrome.driver", "C:\\$INFO_6067\\Selenium_TFT\\chromedriver_win32_2.4\\chromedriver.exe");
			
			// 2.)Create new instance of chrome driver
			WebDriver driver =new ChromeDriver();
			
			// 3.) Use instance of chrome driver to visit google
			driver.get("http://localhost/index.php");
			driver.findElement(By.linkText("Add New Entry")).click();
			
				// Filling of form with new Entry
				WebElement addr_type = driver.findElement(By.id("addr_type"));
				addr_type.sendKeys("Family");
				WebElement addr_first_name = driver.findElement(By.id("addr_first_name"));
				addr_first_name.sendKeys("Amanjot");
				WebElement addr_last_name = driver.findElement(By.id("addr_last_name"));
				addr_last_name.sendKeys("kaur");
				WebElement addr_business = driver.findElement(By.id("addr_business"));
				addr_business.sendKeys("Amanjot");
				WebElement addr_addr_line_1 = driver.findElement(By.id("addr_addr_line_1"));
				addr_addr_line_1.sendKeys("678  st.");
				WebElement addr_addr_line_2 = driver.findElement(By.id("addr_addr_line_2"));
				addr_addr_line_2.sendKeys(" adelaide ");
				WebElement addr_addr_line_3 = driver.findElement(By.id("addr_addr_line_3"));
				addr_addr_line_3.sendKeys("ontario");
				WebElement addr_city = driver.findElement(By.id("addr_city"));
				addr_city.sendKeys("London");
				
				WebElement addr_region = driver.findElement(By.id("addr_region"));
				addr_region.sendKeys("South");
				WebElement addr_country = driver.findElement(By.id("addr_country"));
				addr_country.sendKeys("Canada");
				WebElement addr_post_code = driver.findElement(By.id("addr_post_code"));
				addr_post_code.sendKeys("N598Y9");
				WebElement addr_email_1 = driver.findElement(By.id("addr_email_1"));
				addr_email_1.sendKeys("amanjotgill70@gmail.com");
				WebElement addr_email_2 = driver.findElement(By.id("addr_email_2"));
				addr_email_2.sendKeys("amanjotgill80@gmail.com");
				WebElement addr_email_3 = driver.findElement(By.id("addr_email_3"));
				addr_email_3.sendKeys("amanjotgill90@gmail.com");
				WebElement addr_phone_1_type = driver.findElement(By.id("addr_phone_1_type"));
				addr_phone_1_type.sendKeys("Home");
				WebElement addr_phone_1 = driver.findElement(By.id("addr_phone_1"));
				addr_phone_1.sendKeys("5196007531");
				WebElement addr_phone_2_type = driver.findElement(By.id("addr_phone_2_type"));
				addr_phone_2_type.sendKeys("Mobile");
				WebElement addr_phone_2 = driver.findElement(By.id("addr_phone_2"));
				addr_phone_2.sendKeys("5196007531");
				WebElement addr_phone_3_type = driver.findElement(By.id("addr_phone_3_type"));
				addr_phone_3_type.sendKeys("Work");
				WebElement addr_phone_3 = driver.findElement(By.id("addr_phone_3"));
				addr_phone_3.sendKeys("5196007531");
				
				
				
				WebElement addr_web_url_1 = driver.findElement(By.id("addr_web_url_1"));
				addr_web_url_1.sendKeys("www.google.com");
				WebElement addr_web_url_2 = driver.findElement(By.id("addr_web_url_2"));
				addr_web_url_2.sendKeys("www.yahoo.com");
				WebElement addr_web_url_3 = driver.findElement(By.id("addr_web_url_3"));
				addr_web_url_3.sendKeys("www.yahoo.com");
				
				//Click on save address button
				driver.findElement(By.name("submit_button")).submit();
				
				// Assertion Part 
				 String actualResult = driver.findElement(By.xpath("/html/body/form/div/h2")).getText();
				 String expectedResult = "The new address book entry was added successfully";
				 boolean result = actualResult.equals(expectedResult);
			     assertTrue( result);
			     System.out.println("It Added a new contact");
				
				
				}	
}
